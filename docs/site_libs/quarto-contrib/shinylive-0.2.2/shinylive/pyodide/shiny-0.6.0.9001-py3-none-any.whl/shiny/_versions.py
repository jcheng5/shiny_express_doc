shiny_html_deps = "1.7.5.9001"
bslib = "0.5.1.9000"
htmltools = "0.5.6.9001"
bootstrap = "5.3.1"
requirejs = "2.3.6"

__all__ = (
    "shiny_html_deps",
    "bslib",
    "htmltools",
    "bootstrap",
    "requirejs",
)
